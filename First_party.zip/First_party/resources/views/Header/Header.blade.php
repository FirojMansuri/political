<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="{{ asset('css/header.css') }}">

</head>
<body>

<div class="topnav" id="myTopnav">
    <img src="{{ asset('img/logo.jpeg') }}" height="50px" width="60px" alt=""
    class="logo-img  ">
<a class="active" href="#home">Home</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
  <a href="#about">About</a>
  <div href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars" size='30px'></i>
  </div>

</div>

<div style="padding-left:16px">
  <h2>Top Navigation Example</h2>
  <p>Some content..</p>
</div>
<script>
    function myFunction() {
      var x = document.getElementById("myTopnav");
      if (x.className === "topnav") {
        x.className += " responsive";
      } else {
        x.className = "topnav";
      }
    }
    </script>
    
</body>
</html>
